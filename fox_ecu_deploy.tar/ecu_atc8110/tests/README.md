# Pruebas

Se pueden añadir pruebas unitarias con frameworks ligeros como Catch2. Como punto de partida, los módulos actuales son autocontenidos y pueden probarse instanciando `StateMachine` y verificando las transiciones de estado o la publicación de frames CAN simulados.
