# Pruebas de integraci?n

Escenarios end-to-end que validan la ECU completa.
